#include "esp_camera.h"

extern bool initCamera();